
const OFFICIAL_LIST=[
"New Year","Orthodox Christmas","Women's Day","Labour Day","Victory Day",
"Independence Day","Independence Day of the Republic of Belarus","Day of People’s Unity","October Revolution Day",
"Новый год","Рождество Христово","День женщин","День труда","День Победы",
"День независимости Республики Беларусь","День народного единства","День Октябрьской революции"
];
export function isOfficialHoliday(name:string){const n=name.toLowerCase().trim();return OFFICIAL_LIST.some(x=>n.includes(x.toLowerCase()));}
