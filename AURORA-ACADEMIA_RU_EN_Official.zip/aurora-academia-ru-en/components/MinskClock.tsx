
"use client";
import { useEffect, useState } from "react";
import { useLocale } from "@/lib/useLocale";
export default function MinskClock(){const [now,setNow]=useState<string>("");const locale=useLocale();async function tick(){try{const r=await fetch("http://worldtimeapi.org/api/timezone/Europe/Minsk",{cache:"no-store"});const d=await r.json();const dt=new Date(d.datetime);setNow(dt.toLocaleString(locale==='ru'?'ru-RU':'en-GB',{dateStyle:"full",timeStyle:"short"}));}catch{setNow(new Date().toLocaleString(locale==='ru'?'ru-RU':'en-GB'));}}useEffect(()=>{tick();const t=setInterval(tick,60000);return()=>clearInterval(t);},[locale]);return <span>{now||"—"}</span>;}
