
"use client";
import { useLocale, Locale } from "@/lib/useLocale";
export default function LangSwitch(){
  const locale=useLocale();
  function setLang(l:Locale){const u=new URL(window.location.href);u.searchParams.set("lang",l);window.location.href=u.toString();}
  return (<div style={{display:'flex',gap:8}}>
    <button onClick={()=>setLang('ru')} style={{padding:'4px 8px',borderRadius:8,border:'1px solid rgba(255,255,255,.2)',background:locale==='ru'?'#1e293b':'transparent',color:'#fff'}}>RU</button>
    <button onClick={()=>setLang('en')} style={{padding:'4px 8px',borderRadius:8,border:'1px solid rgba(255,255,255,.2)',background:locale==='en'?'#1e293b':'transparent',color:'#fff'}}>EN</button>
  </div>);
}
