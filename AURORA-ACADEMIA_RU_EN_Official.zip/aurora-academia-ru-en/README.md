
# AURORA-ACADEMIA (RU/EN) with Official Holidays + Language Toggle
Run:
  npm i
  npm run dev
Deploy: https://vercel.com/docs

Trusted sources:
- Open-Meteo: https://open-meteo.com/en/docs
- WorldTimeAPI: http://worldtimeapi.org/api/timezone/Europe/Minsk
- Globe.gl: https://globe.gl/
- Next.js: https://nextjs.org/docs
- Vesnik GRSU: http://vesnik.grsu.by/?p=last&lang=en
- Vestnik BrSU: https://www.brsu.by/science/vestnik-brgu
- NASB Journals: https://nasb.gov.by/eng/publications/nauchnye-zhurnaly/
- DaysPedia (Belarus calendar): https://dayspedia.com/by/calendar/
- Belarus.by — National holidays: https://www.belarus.by/en/about-belarus/holidays
- Presidential portal: https://president.gov.by/
